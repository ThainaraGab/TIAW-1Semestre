function leDados () {
    let strDados = localStorage.getItem('db');
    let objDados = {};

    if(strDados) {
        objDados = JSON.parse (strDados)
    }
    else{
         objDados = { artigos: [
            {artigo: "Computação", link: "https://www.nucleodoconhecimento.com.br/ciencia-da-computacao", autor:"Eduardo"}, 
           
            
            ]}
    }
    return objDados;
}

function salvaDados (dados) {
    localStorage.setItem ('db', JSON.stringify (dados));
}

function incluirArtigo () {
    let objDados = leDados();

    let strArtigo = document.getElementById ('campoArtigo').value;
    let strLink = document.getElementById("campoLink").value;
    let strAutor = document.getElementById("campoAutor").value;
    let novoArtigo = {
        artigo: strArtigo,
        link: strLink,
        autor: strAutor
    };
    objDados.artigos.push (novoArtigo);

    salvaDados (objDados);

    imprimeDados ();

}

function imprimeDados () {
    let tela = document.getElementById('tela');
    let strHtml = '';
    let objDados = leDados ();

    for (i=0; i< objDados.artigos.length; i++) {
        strHtml += `<p>${objDados.artigos[i].artigo} - ${objDados.artigos[i].link} -  ${objDados.artigos[i].autor}</p>` 
    }
    
    tela.innerHTML = strHtml;
}

// Configura os botões
document.getElementById ('btnCarregaDados').addEventListener ('click', imprimeDados);
document.getElementById ('btnIncluirArtigo').addEventListener ('click', incluirArtigo);